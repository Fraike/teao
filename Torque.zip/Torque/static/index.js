

function optimiumPrecision(fNum) {

if(fNum.toString().length > 15)

return fNum.toPrecision(15) * 1;

else

return fNum;

}

function correctoutput(number) 
{
	var poz;
	var stringvysl=number.toString();
	var bylojiny0=0;
	var platnamista=0;
	var ciscis=number;
	for(x=0;x<stringvysl.length;x++) 
	{
		code=stringvysl.charCodeAt(x);
		if ((code>47)&&(code<58)) 
		{
			if (code==48) 
			{
				if (bylojiny0) platnamista++;
			}
			else 
			{
				platnamista++; bylojiny0=1;
			}
		}
		if (!(((code>47)&&(code<58))||(code==44)||(code==46))) {break;};
		if (platnamista==12) {poz=x;break;}
	}
	if (platnamista==12)
	{
		stringvysl.toLowerCase();
		indexe=stringvysl.indexOf("e");
		novy="";
		x=stringvysl.length-1;
		if (indexe!=-1) 
		{	
			for(x=stringvysl.length-1;x>-1;x--) 
			{
				novy=stringvysl.charAt(x)+novy;
				if (x==indexe) {break;};
			}
			x--;
		}
		for(;x>-1;x--) 
		{
			code=stringvysl.charCodeAt(x);
			if ((code>47)&&(code<58)){novy="0"+novy;}
			else {novy=stringvysl.charAt(x)+novy;};
			if (x==poz) {break;};
		}
		x--;
		var dal;
		if (stringvysl.charCodeAt(poz)>52) {dal=1;}
		else {dal=0;};
		if (dal==1) 
		{
			for(;x>-1;x--) 
			{
				code=stringvysl.charCodeAt(x);
				if ((code>47)&&(code<58)) 
				{
					code=code+dal;
					dal=0;
					if (code>57){code=48;dal=1;};
					novy=vratznak(code)+novy;
				}
				else 
				{novy=stringvysl.charAt(x)+novy;};
			}
		}
		else 
		{
			for(;x>-1;x--)
			{
				novy=stringvysl.charAt(x)+novy;
			};
		};
		var ciscisnew=novy.valueOf()*1;
		rozdil=Math.abs((ciscisnew-number)/number); 
		if (rozdil<1e-10) ciscis=ciscisnew;
	}
	return ciscis;
}

function vypocet() 
{
	
	
		var vstup;
		if (jQuery("#quantity").val()=="")
		{
			vstup="0"
		} 
		else 
		{
			vstup=jQuery("#quantity").val()
		};
		//vstup=correctinput(vstup);
		if(isNumber(vstup))
		{
			vstup=eval(vstup);
			//if (vstup == 1) {
			//	vstup = 1.000000000000001;
			//}
			vysl=(jQuery("#box01").val()/jQuery("#box02").val())*vstup;
			jQuery("#newresult").val(optimiumPrecision(correctoutput(vysl)));
		}
	
}

function vypocet1() 
{
	//var t = jQuery("#lengthCal");
	//with (document.convert) 
	if(1)
	{
		var vstup1;
		if (jQuery("#newresult").val()=="")
		{
			vstup1="0"
		} 
		else 
		{
			vstup1=jQuery("#newresult").val()
		};
		//vstup=correctinput(vstup);
		if(isNumber(vstup1))
		{
			vstup1=eval(vstup1);
			//if (vstup == 1) {
			//	vstup = 1.000000000000001;
			//}
			vysl1=(jQuery("#box02").val()/jQuery("#box01").val())*vstup1;
			jQuery("#quantity").val(optimiumPrecision(correctoutput(vysl1)));
		}
	}
}

function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

function vratznak(cis)
{
	switch(cis){
		case 48:return "0";
		case 49:return "1";
		case 50:return "2";
		case 51:return "3";
		case 52:return "4";
		case 53:return "5";
		case 54:return "6";
		case 55:return "7";
		case 56:return "8";
		case 57:return "9";
	}
}

//$("form").submit(function(e){
    //var form = $(this);
    //vypocet();
    //return false;
 //});

